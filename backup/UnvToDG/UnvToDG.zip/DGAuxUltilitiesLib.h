#ifndef DGAUXULTILITIESLIB_H_INCLUDED
#define DGAUXULTILITIESLIB_H_INCLUDED
#include <QString>
namespace auxUlti
{
	/*Function gets working directory*/
    QString workingdir();
}
#endif // DGAUXULTILITIESLIB_H_INCLUDED
